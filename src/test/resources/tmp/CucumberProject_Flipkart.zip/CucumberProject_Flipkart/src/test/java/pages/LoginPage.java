package pages;

import Base.BaseUtil;
import net.bytebuddy.asm.Advice;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class LoginPage extends BaseUtil {
    By searchText = By.xpath("//input[@placeholder='Search for products, brands and more']");
    By searchButton = By.xpath("//button[@class='vh79eN']");
    By category = By.xpath("//a[@class='_3XS1AH _32ZSYo']");
    By usrname = By.xpath("//*[@id=\"username\"]");
    By usrpaswd = By.xpath("//*[@id=\"password\"]");
    By signInButton = By.xpath("//button/div[contains(text(),'Sign In')]");
    By continueBT = By.xpath("//button[@type='submit']");
    By signInButtonPG = By.xpath("//*[@id=\"idSIButton9\"]");
    By usrpaswdPG = By.xpath("//*[@name=\"passwd\"]");
By yesBT=By.xpath("//input[contains(@id,'idSIButton')]");
    public void enterUsrNameAndpasswd(String usrName, String passwd) {
        getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
        getDriver().findElement(usrname).clear();
        getDriver().findElement(usrname).sendKeys(usrName);
        getDriver().findElement(usrpaswd).clear();
        getDriver().findElement(usrpaswd).sendKeys(passwd);
        getDriver().findElement(signInButton).click();
    }

    public void enterUsrNameAndpasswdPG(String usrName, String passwd) {
        getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        getDriver().findElement(usrname).clear();
        getDriver().findElement(usrname).sendKeys(usrName);
        getDriver().findElement(continueBT).click();
        getDriver().findElement(usrpaswdPG).clear();
        getDriver().findElement(usrpaswdPG).sendKeys(passwd);
        getDriver().findElement(signInButtonPG).click();
        getDriver().findElement(yesBT).click();
    }

    public void navigateToUrl(String url) {
        getDriver().manage().window().maximize();
        getDriver().navigate().to(url);
        getDriver().manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
    }

    By bsnesButton = By.xpath("//li[@role='listitem']/descendant::h2[contains(text(),\"Business\")]");

    public void clickBusiness() throws InterruptedException {
        Thread.sleep(2000);
        getDriver().findElement(bsnesButton).click();
    }

    By clubSearchBox = By.xpath("//input[@id=\"searchInput\"]") ;
    public void searchClub(String clubNumr){
        getDriver().findElement(clubSearchBox).sendKeys(clubNumr);
    }

    public void clickClub(String clubNumbr) throws InterruptedException {
        Thread.sleep(2000);
        String xpathVal = "//td[@data-abc-id=\"number\" and contains(text(),'"+clubNumbr+"')]";
        By club = By.xpath(xpathVal);
        getDriver().findElement(club).click();
    }

    By memButton = By.xpath("//*[@data-abc-id=\"navBarLink\" and contains(text(),'Members')]");

    public void clickMemberButton() throws InterruptedException {
        Thread.sleep(4000);
        getDriver().findElement(memButton).click();
    }

    By srchButton = By.xpath("//input[@id='memberListSearchInput']");
    By memberButton = By.xpath("//a[@data-abc-id=\"navBarLink\" and contains(text(),'Members')]");

    By backButtonMemberSearch = By.xpath("//*[@class=\"ui-icon icon-arrow-left-thin\"]");
    By srchClearButton = By.xpath("//*[@data-abc-id='memberListSearchInputTooltip']//*[@data-abc-id='iconClose']");
    By memList = By.xpath("//*[@data-abc-id='memberList']");

    public String searchMemberAndGetMemType(String fName, String clubNum, String agrementNum) throws InterruptedException {
        int count = getDriver().findElements(memList).size();

        if(count==1){
            getDriver().findElement(memList).click();
            try {
                Thread.sleep(5000);
                if(1==getDriver().findElements(srchClearButton).size())
                    getDriver().findElement(srchClearButton).click();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }

        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        getDriver().findElement(memberButton).click();
        getDriver().findElement(srchButton).click();


        if(1==getDriver().findElements(memList).size()){
            try {
                Thread.sleep(4000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            getDriver().findElement(srchClearButton).click();
        }

        // if agrementNum i.e. length of memberId is less than 2, search does not give expected result
        if(agrementNum.length() <=2){
            getDriver().findElement(srchButton).sendKeys(fName);
        }else{
            getDriver().findElement(srchButton).sendKeys(agrementNum);
        }


        String agrNumXpath = "";
        if(clubNum.length()==3){
            clubNum = "0"+clubNum;
        }

        agrementNum = agrementNum.replace(".0","");
        if(agrementNum.startsWith("B")){
            agrNumXpath = "//td[@data-abc-id='agreement']//span[contains(text(),\"0" +clubNum+""+agrementNum+"\")]";
        }else if(agrementNum.startsWith("0000")){
            agrNumXpath = "//td[@data-abc-id='agreement']//span[contains(text(),\"00" +clubNum+""+agrementNum+"\")]";
        }else if(agrementNum.length()==4){
            agrNumXpath = "//td[@data-abc-id='agreement']//span[contains(text(),\"00" +clubNum+"00"+agrementNum+"\")]";
        }else if(agrementNum.endsWith("B")){
            agrNumXpath = "//td[@data-abc-id='agreement']//span[contains(text(),\"00" +clubNum+""+agrementNum+"\")]";
        }else if(agrementNum.length()<4){
            if(agrementNum.length()==1){
                agrNumXpath = "//td[@data-abc-id='agreement']//span[contains(text(),\"00" +clubNum+"00000"+agrementNum+"\")]";
            }
            else if(agrementNum.length()==2){
                agrNumXpath = "//td[@data-abc-id='agreement']//span[contains(text(),\"00" +clubNum+"0000"+agrementNum+"\")]";
            }
            else if(agrementNum.length()==3){
                agrNumXpath = "//td[@data-abc-id='agreement']//span[contains(text(),\"00" +clubNum+"000"+agrementNum+"\")]";
            }

        }else if(agrementNum.length()==6){
            agrNumXpath = "//td[@data-abc-id='agreement']//span[contains(text(),\"00" +clubNum+""+agrementNum+"\")]";
        }
        else
            {
            agrNumXpath = "//td[@data-abc-id='agreement']//span[contains(text(),\"00" +clubNum+"0"+agrementNum+"\")]";
        }


        By agrementNumber = By.xpath(agrNumXpath);

        if(getDriver().findElements(agrementNumber).size()>0){
            getDriver().findElement(agrementNumber).click();
            return "Pass";
        }else{
            return "Fail";// finalMemType;
        }
    }


        public Boolean searchMemberByFirstAndSecondName(String fName, String sName) throws InterruptedException {
        boolean findMem = false;
        int count = getDriver().findElements(backButtonMemberSearch).size();
        if(count==1){
            getDriver().findElement(backButtonMemberSearch).click();
            getDriver().findElement(srchClearButton).click();
        }


        getDriver().findElement(srchButton).clear();
        getDriver().findElement(srchButton).sendKeys(fName);


        By membersearchXPath = By.xpath("//*[starts-with(text(), '"+sName +"')  and contains(text(), '"+fName +"')]");
        int memberCount = getDriver().findElements(membersearchXPath).size();
        if(memberCount==1){
            findMem = true;
            getDriver().findElement(membersearchXPath).click();
        }
        return findMem;
    }


    public void getIntoMemberAccount(){
    }

    public void searchProduct(String product) {
        getDriver().findElement(searchText).clear();
        getDriver().findElement(searchText).sendKeys(product);
        getDriver().findElement(searchButton).click();
    }


    By subscriptiontab = By.xpath("//div[contains(text(),'Subscriptions')]");

    public void clickSubscriptionTab() {
        getDriver().findElement(subscriptiontab).click();
    }

    By MemberAccountTab = By.xpath("//div[contains(text(),'Member Account')]");
    public void clickMemberAccountTab() {
        getDriver().findElement(MemberAccountTab).click();
    }

    By paymentsTab = By.xpath("//*[@data-text='Payments']");
    public void clickPaymentsTab() {
        getDriver().findElement(paymentsTab).click();
    }

    By memStatus = By.xpath("//*[@data-abc-id='memberStatus']");
    public String getMemberStatus() throws InterruptedException {
        Thread.sleep(2000);
         return getDriver().findElement(memStatus).getText();
    }


    // Get Complete Table Data
    public Map<Integer,List<String>> getTableData(String tableName) {

        List<WebElement> rowsList = getDriver().findElements(By.xpath("//tr[@data-abc-id='"+tableName +"']"));
//        System.out.println(rowsList.size());
        List<WebElement> columnsList = null;

        List<String> rowData = new ArrayList<String>();

        Map<Integer,List<String>> tableData = new HashMap<Integer,List<String>>();

        System.out.println();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
    int i = 0;
    for (WebElement row : rowsList) {
try {
    columnsList = row.findElements(By.tagName("td"));
}catch(StaleElementReferenceException e){

}
////columnsList.size();
//        System.out.println(columnsList.size());
        String data = "";
        for (WebElement column : columnsList) {
            // System.out.print(column.getText() + ", ");
            data = column.getText();
            rowData.add(data);
        }
        tableData.put(i, rowData);
        i++;
    }
}catch (Exception e){
    e.printStackTrace();
}
return tableData;
    }


    public LinkedHashMap<String,List<String>> readExcelFile(String filePath) throws IOException {
        FileInputStream file = new FileInputStream(new File(filePath));

        // Create Workbook instance holding reference to .xlsx file
        XSSFWorkbook workbook = new XSSFWorkbook(file);

        // Get first/desired sheet from the workbook
        XSSFSheet sheet = workbook.getSheetAt(0);


        Map<String,List<String>> memberDetails = new LinkedHashMap<String,List<String>>();
        int rowcount = sheet.getLastRowNum();
        String data = "";
        System.out.println("Total row number: " + rowcount);

        for (int i = 1; i < rowcount + 1; i++) {
            //Create a loop to get the cell values of a row for one iteration
            Row row = sheet.getRow(i);
            List<String> arrName = new ArrayList<String>();
            for (int j = 0; j < row.getLastCellNum(); j++) {
                // Create an object reference of 'Cell' class
            Cell cell = row.getCell(j);

            try{
                // Add all the cell values of a particular row
                switch (cell.getCellType()) {
                    case NUMERIC:
                        // System.out.print(cell.getNumericCellValue() + "\t");
                        data = String.valueOf(cell.getNumericCellValue());
                        arrName.add(data);
                        break;
                    case STRING:
                        // System.out.print(cell.getStringCellValue() + "\t");
                        data = cell.getStringCellValue();
                        arrName.add(data);
                        break;
                    case _NONE:
                        arrName.add(null);
                        break;
                    case BLANK:
                        arrName.add(null);
                        break;
                 }}catch (NullPointerException e){
                e.printStackTrace();
            }}
            System.out.println();
            if(filePath.contains("paymentTestData")){
                memberDetails.put(arrName.get(0),arrName);
            }else{
                memberDetails.put(arrName.get(3),arrName);
            }
        }
        System.out.println();
        return (LinkedHashMap<String, List<String>>) memberDetails;
    }

    // By clubClearButton = By.xpath("//*[@id='organizationSwitcherInput']/../i[@aria-label='Clear Icon']");
    By clubClearButton = By.xpath("//*[@data-abc-id='iconClose']");



    public void clearClub(){
        int isClubSelected = getDriver().findElements(clubClearButton).size();
        if(isClubSelected==1)
            getDriver().findElement(clubClearButton).click();
    }



    By status = By.xpath("(//td[@data-abc-id='status'])[1]");
    By paymentId = By.xpath("(//td[@data-abc-id='paymentMethodId'])[1]");
    By amount = By.xpath("(//td[@data-abc-id='amountDue'])[1]");

    By statementAmount = By.xpath("(//table[@data-abc-id=\"accountStatementsTable\"]//td[@data-abc-id='amountDue'])[1]");
    By statementCreatedDate = By.xpath("(//table[@data-abc-id=\"accountStatementsTable\"]//td[@data-abc-id='createdDate'])[1]");
    By statementPostedDate = By.xpath("(//table[@data-abc-id=\"accountStatementsTable\"]//td[@data-abc-id='postingDate'])[1]");




    public String getFirstPaymentType(String usrDate, String expectedInvAmnt){

        By dataTest = By.xpath("//*[@data-abc-id='createdDate' and contains(text(),'"+usrDate+"')]//ancestor::tr//*[@data-abc-id='transactionStatus' and contains(text(),'Recurring Payment')]");
        By status = By.xpath("//*[@data-abc-id='createdDate' and contains(text(),'"+usrDate+"')]//ancestor::tr//span[@data-abc-id='paymentSecondary']");
        By paymentMethod = By.xpath("//*[@data-abc-id='createdDate' and contains(text(),'"+usrDate+"')]//ancestor::tr//*[@data-abc-id='paymentMethodPrimary']");
        By amount = By.xpath("//*[@data-abc-id='createdDate' and contains(text(),'"+usrDate+"')]//ancestor::tr//*[@data-abc-id='amount']//span");
        By postDate = By.xpath("//*[@data-abc-id='createdDate' and contains(text(),'"+usrDate+"')]/ancestor::span/../*[@data-abc-id='dateSecondary']");
        By invoiceStatus = By.xpath("//*[@data-abc-id='dateSecondary' and contains(text(),'"+usrDate+"')]/../../..//span[@data-abc-id=\"transactionSecondary\"]");

        int recurringPayment = getDriver().findElements(dataTest).size();

        String finalDataTobeVerified = "";

        String getStatus = "", getPaymntId = "", getAmount = "", createdDate = "", postedDate = "";

        if(recurringPayment == 1 ){
            // From Transaction History Table
             getStatus = getDriver().findElement(status).getText();
             getPaymntId = getDriver().findElement(paymentMethod).getText();
             getAmount = getDriver().findElement(amount).getText().replace("$","").replace(",","");
             createdDate = usrDate;
             postedDate = getDriver().findElement(postDate).getText();
        }
        else
        {
            getDriver().navigate().refresh();
            int invoiceStatusSize = getDriver().findElements(invoiceStatus).size();
            if(invoiceStatusSize == 1){
                getStatus = getDriver().findElement(invoiceStatus).getText();
            }

        }

        finalDataTobeVerified = getPaymntId +","+ getStatus +","+ ","+ "," + expectedInvAmnt + ","+  getAmount +"," + createdDate+","+ postedDate ;  // getStatementAmount +","+ statusInfo
        return finalDataTobeVerified;
    }

     File file = new File("C:\\Users\\yrajendra\\Desktop\\VerifiedData.csv");
//    String rsltFilePath = datafile.getData("resultFile");
//    File file = new File(rsltFilePath);


        public void explicitlyWaitOnElement(int timeout){
            new WebDriverWait(getDriver(),timeout).
                    until(ExpectedConditions.alertIsPresent());

        }
    public void fileAppendData(String data) throws IOException {
        FileWriter fr = new FileWriter(file, true);
        BufferedWriter br = new BufferedWriter(fr);
        br.write(data);
        br.close();
        fr.close();
    }

    By pgTransaction = By.xpath("//*[@data-abc-id='navCardSkeletonTitle' and contains(text(),'Transactions')]");
    public void clickTransactionModule(){
        getDriver().findElement(pgTransaction).click();
    }

    By batchTransaction = By.xpath("//*[@data-abc-id='navCardSkeletonTitle' and contains(text(),'Batch Monitor')]");
    public void clickBatchModule(){
        getDriver().findElement(batchTransaction).click();
    }

    By startDate = By.xpath("//*[@data-abc-id=\"transactionsDateRangeStart\"]//input");
    public void enterBeginDate(String date){
        getDriver().findElement(startDate).click();
        getDriver().findElement(startDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(startDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(startDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(startDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(startDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(startDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(startDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(startDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(startDate).sendKeys(date);
    }

    By endDate = By.xpath("//*[@data-abc-id=\"transactionsDateRangeEnd\"]//input");
    public void enterEndDate(String date){
        getDriver().findElement(endDate).click();
        getDriver().findElement(endDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(endDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(endDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(endDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(endDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(endDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(endDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(endDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(endDate).sendKeys(date);
    }


    By bnkButton = By.xpath("//*[@data-abc-id=\"/app/transactionsTab\"]");
    public void clickBankButton(){
        getDriver().findElement(bnkButton).click();
    }

    By creditCardButton = By.xpath("//*[@data-abc-id=\"/app/transactions/credit-cardTab\"]");
    public void clickCreditCardButton(){
        getDriver().findElement(creditCardButton).click();
    }
By addFilter=By.xpath("//button[@data-abc-id=\"addFilterMenu\"]");
    public void clickAddFilter(){
        getDriver().findElement(addFilter).click();
    }


    By lastFourDigit=By.xpath("//div[@data-valuetext='Last Four']");
    public void clickLastFourDigit(){
        getDriver().findElement(lastFourDigit).click();

    }

//        JavascriptExecutor executor = (JavascriptExecutor)driver;
//        executor.executeScript("arguments[0].click();", lastFourDigit);


    By fourNums = By.xpath("//input[@id='lastFourInput']");
    public void  payment4Nums(String num) throws InterruptedException {
        getDriver().findElement(fourNums).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(fourNums).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(fourNums).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(fourNums).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(fourNums).sendKeys(num);
        Thread.sleep(3000);
        getDriver().findElement(fourNums).sendKeys(Keys.ENTER);
    }
    By pgAmount = By.xpath("//div[@class='styles--MHthb']//span[@data-abc-id='amount']");
    public String getPgAmount(){
        return getDriver().findElement(pgAmount).getText();
    }

    By pgAccountHolderName = By.xpath("//div[@class='styles--MHthb']//span[@data-abc-id='accountHolderName']");
    public String getPgAcntHolderName(){
        return getDriver().findElement(pgAccountHolderName).getText();
    }

    By pgStatus = By.xpath("//span[@data-abc-id='status']");
    public String getPgStatus(){
        return getDriver().findElement(pgStatus).getText();
    }

    By pgDate = By.xpath("//div[@class='styles--MHthb']//span[@data-abc-id='effectiveDate']");
    public String getPgDAte(){
        return getDriver().findElement(pgDate).getText().replace(","," - ");
    }

   public String getClubName(String clubNumber){

        switch(clubNumber){
            case "520": return "TAN 24-7 FREMONT";
            case "2000": return	"JAMES A. BOTTIN";
            case "2002": return	"BOTTIN FAMILY REAL ESTATE LLC";
            case "2908": return	"HARVEY'S GYM OF FRANKLIN";
            case "3683": return	"MG SPORTS AND FITNESS";
            case "3706": return	"New Life Fitness Center";
            case "3726": return	"JUNGLE GYM FITNESS";
            case "3948": return	"NEW ENGLAND FIT AND MMA";
            case "3959": return "LIFE FITNESS PROS";
            case "4150": return	"Pilgers Womens Bootcamp";
            case "4572": return	"THE FITNESS ZONE";
            case "4613": return	"BAM ADVENTURE BOOT CAMP";
            case "5319": return	"ROCK CITY MMA";
            case "5342": return	"CATOCTIN CROSSFIT PURCELLVILLE";
            case "5552": return	"CONFLUENCE CLUB WORKS MXMETRIC";
            case "5810": return	"ELITE COMBAT ACADEMY";
            case "5855": return	"PAGELAND FITNESS AND WELLNESS";
            case "6060": return	"THE PUMPHOUSE HENDERSONVILLE";
            case "7095": return	"UNITED KARATE STUDIO";
            case "7722": return	"MUSCLES AND CURVES GYM";
            case "7875": return	"TKI FAMILY MARTIAL ARTS";
            case "4099": return "Old Skool Fight Sports Fitness";
            case "7541": return "Titus Strength";
            case "6019" : return "LADIES FITNESS AND WELLNESS MB";
            case "8730" : return "PLAINFIELD GYM AND TAN";
            case "9971" : return "Evendo LLC";
            case "4300" : return "XTREME PHYSIQUE";
            case "7997" : return "CONTOURS EXPRESS";
            case "2928"	: return "REVOLUTION MIXED MARTIAL ARTS";
            case "8205"	: return "CABARRUS PROF FIREFIGHTER ASSN";
            case "3204" : return "BRUTAL IRON GYM";
            case "3505" : return "TEXAS ROWING CENTER";
            default:
                return	"Update the club Name in CodeBase";
        }
    }


    // Batch Data fetch Caode
    By batchDataStartDate = By.xpath("//*[@data-abc-id='filesModifiedDateRangeStart']//input");
    public void batchBeginDate(String date){
        getDriver().findElement(batchDataStartDate).click();
        getDriver().findElement(batchDataStartDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(batchDataStartDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(batchDataStartDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(batchDataStartDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(batchDataStartDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(batchDataStartDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(batchDataStartDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(batchDataStartDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(batchDataStartDate).sendKeys(date);
    }

    By batchDataEndDate = By.xpath("//*[@data-abc-id='filesModifiedDateRangeEnd']//input");
    public void batchEndDate(String date){
        getDriver().findElement(batchDataEndDate).click();
        getDriver().findElement(batchDataEndDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(batchDataEndDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(batchDataEndDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(batchDataEndDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(batchDataEndDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(batchDataEndDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(batchDataEndDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(batchDataEndDate).sendKeys(Keys.BACK_SPACE);
        getDriver().findElement(batchDataEndDate).sendKeys(date);
    }



    public void clickBatch(int batchNo){
        By batchNoXpath = By.xpath("//tr[@data-abc-id='fileMonitorRow']["+ batchNo +"]");
        getDriver().findElement(batchNoXpath).click();
    }



    public void batchClickClub(int clubPos){
        By clubNoXpath = By.xpath("//tr[@data-abc-id='paymentBatchMonitorsTableRow']["+ clubPos +"]");
        getDriver().findElement(clubNoXpath).click();
    }


    public void clickMainBatch(){
        By mainBatch = By.xpath("//a[@data-abc-id='batchFilesMonitoringBreadcrumb']");  //what is the use of this
        getDriver().findElement(mainBatch).click();
    }
    By merchantName = By.xpath("//*[@data-abc-id='batchInfo']//p");
    public String getClubName(){
        return getDriver().findElement(merchantName).getText();
    }

    By batchName = By.xpath("//*[@data-abc-id='transactionDetailsBreadcrumb']");
    public String getBatchName(){
        return getDriver().findElement(batchName).getText();
    }


    By fileName = By.xpath("//*[@data-abc-id='primaryBatchDetailsBreadcrumb']");
    public String getFileName(){
        return getDriver().findElement(fileName).getText();
    }
    //
//    public String getCategory() {
//        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(4));
//        wait.until(ExpectedConditions.visibilityOfElementLocated(category));
//        return getDriver().findElement(category).getText();
//    }


public void sleep(int sleepTime){
    try {
        Thread.sleep(sleepTime);
    }catch(Exception e){

    }
}
    public void connectWhatsApp() throws InterruptedException {
        LoginPage lpOb = new LoginPage();
        String pgUrl = "https://web.whatsapp.com/";           // datafile.getData("paymentGatewayUrl");
        lpOb.navigateToUrl(pgUrl);
        Thread.sleep(6000);
        // WebDriverWait(driver, 600);
    }

    public String getData(){
        String target = "Deepti";
        String msg = "Message sent using Automation!!!";
        return target+","+msg;
    }



    By name_inp_xpath = By.xpath("//div[@class='_13NKt copyable-text selectable-text' and @data-tab='3']");

    public void sendDataToCustomer(String target, String msg) throws InterruptedException {

        By searchButton = By.xpath("//div[@class='_13NKt copyable-text selectable-text']") ;
        By targetPerson = By.xpath("//span[contains(@title,'"+ target +"')]");


        WebDriverWait wait = new WebDriverWait(driver,30);
        // wait.until(ExpectedConditions.visibilityOfElementLocated(targetPerson));

        getDriver().findElement(searchButton).click();
        getDriver().findElement(searchButton).sendKeys(target);
        getDriver().findElement(targetPerson).click();


        getDriver().findElement(name_inp_xpath).click();

        By sendButton = By.xpath("//button[@class='_4sWnG']");
        By msgTextBox = By.xpath("//*[@class='_13NKt copyable-text selectable-text' and @data-tab='6']");
        getDriver().findElement(msgTextBox).sendKeys(msg);

        getDriver().findElement(sendButton).click();

        Thread.sleep(2000);
    }



//    public void navigateToUrlPG(String url) {
//        getDriver().manage().window().maximize();
//        getDriver().navigate().to();
//    }
}